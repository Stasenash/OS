package com.stasenash.helloapplication;

public class State {
    public static String name = "Andrey";
    public static int age = 18;
}

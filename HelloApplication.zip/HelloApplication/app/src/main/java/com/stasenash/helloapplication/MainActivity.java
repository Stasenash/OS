package com.stasenash.helloapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.TextView;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.textView);
        tv.setText(this.getClass().getSimpleName());
        findViewById(R.id.buttonTest).setOnClickListener(new View.OnClickListener()
        {
            @Override public void onClick(View view)
            {
                tv.setText("My name is ");
                tv.append(State.name);
                tv.append(" i'm ");
                tv.append(Integer.toString(State.age));
                tv.append(" years old"); }
        });
    }
        @Override protected void onStart() {
        super.onStart();
        State.name = "Mikhail";
    }
    @Override protected void onStop() {
        super.onStop();
        State.name = "Igor";
    }
    @Override protected void onPause()
    {
        super.onPause(); State.age = 21;
    }
    @Override protected void onResume() {
        super.onResume(); State.age = 22;
    }
}


package com.stasenash.helloapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class DisplayMessageActivity extends AppCompatActivity {

    TextView tv;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);
        tv = findViewById(R.id.textView);
        tv.setText(this.getClass().getSimpleName());
        findViewById(R.id.buttonTest).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                Intent intent = new Intent(DisplayMessageActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
    @Override protected void onStart() {
        super.onStart();
        State.name = "Dmitriy";
    }
    @Override protected void onStop() {
        super.onStop();
        State.name = "Daria";
    }
        @Override protected void onPause() {
        super.onPause();
        State.age = 19;
    }
        @Override protected void onResume() {
        super.onResume();
        State.age = 20;
    }
}



